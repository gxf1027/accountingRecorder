package cn.gxf.spring.bill.receiver;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.ChannelAwareMessageListener;
import org.springframework.amqp.support.converter.SimpleMessageConverter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.rabbitmq.client.Channel;

import cn.gxf.spring.bill.mailsender.FpNoticeSender;
import cn.gxf.spring.quartz.job.model.FinancialProductsNotice;

public class FinancialProductsNoticeListener implements ChannelAwareMessageListener{

	private ThreadPoolTaskExecutor taskExecutor;
	private SimpleMessageConverter simpleMsgConvt;
	private FpNoticeSender sender;
	
	@Override
	public void onMessage(Message message, Channel channel) throws Exception {
		
		FinancialProductsNotice notice = (FinancialProductsNotice) simpleMsgConvt.fromMessage(message);
		
		// ͨ���̳߳ط���
		this.taskExecutor.execute(new SendingEmailProcess(sender, notice));
		
	}
	
	public void setSimpleMsgConvt(SimpleMessageConverter simpleMsgConvt) {
		this.simpleMsgConvt = simpleMsgConvt;
	}
	
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	public void setSender(FpNoticeSender sender) {
		this.sender = sender;
	}
}
