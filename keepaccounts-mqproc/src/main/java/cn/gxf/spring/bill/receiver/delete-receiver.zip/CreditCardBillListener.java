package cn.gxf.spring.bill.receiver;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.ChannelAwareMessageListener;
import org.springframework.amqp.support.converter.SimpleMessageConverter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.rabbitmq.client.Channel;

import cn.gxf.spring.bill.mailsender.CcBillSender;
import cn.gxf.spring.quartz.job.model.CreditCardBill;

public class CreditCardBillListener implements ChannelAwareMessageListener{

	private ThreadPoolTaskExecutor taskExecutor;
	private SimpleMessageConverter simpleMsgConvt;
	private CcBillSender sender;
	
	@Override
	public void onMessage(Message message, Channel channel) throws Exception {
		
		CreditCardBill bill = (CreditCardBill) simpleMsgConvt.fromMessage(message);
		
		taskExecutor.execute(new SendingEmailProcess(sender, bill));
	}
	
	public void setSimpleMsgConvt(SimpleMessageConverter simpleMsgConvt) {
		this.simpleMsgConvt = simpleMsgConvt;
	}
	
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	public void setSender(CcBillSender sender) {
		this.sender = sender;
	}
}
